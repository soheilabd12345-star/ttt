<?php
/*
Plugin Name: MeetingAI Pro Integration
Plugin URI: https://your-site.com
Description: هوش مصنوعی مدیریت جلسات با قابلیت ذخیره‌سازی در وردپرس و تحلیل هوشمند صوت
Version: 1.1
Author: MeetingAI Team
Text Domain: meetingai-pro
*/

// 1. ایجاد پست تایپ اختصاصی برای جلسات
add_action('init', function() {
    register_post_type('meeting_session', [
        'labels' => [
            'name' => 'جلسات هوشمند',
            'singular_name' => 'جلسه',
            'add_new' => 'افزودن جلسه جدید',
            'edit_item' => 'ویرایش جلسه',
            'all_items' => 'همه جلسات'
        ],
        'public' => true,
        'show_in_rest' => true, // برای دسترسی REST API
        'supports' => ['title', 'editor', 'custom-fields'],
        'menu_icon' => 'dashicons-microphone',
    ]);
});

// 2. اجازه دسترسی به متادیتاها در REST API
add_action('rest_api_init', function() {
    register_rest_field('meeting_session', 'session_data', [
        'get_callback' => function($post) {
            return get_post_meta($post['id'], 'session_json', true);
        },
        'update_callback' => function($value, $post) {
            update_post_meta($post->ID, 'session_json', $value);
        }
    ]);
});

// 3. کد کوتاه برای نمایش اپلیکیشن در صفحات وردپرس
add_shortcode('meetingai_app', function() {
    $plugin_url = plugin_dir_url(__FILE__);
    
    // اضافه کردن قابلیت‌های میکروفون و دوربین به iframe برای کارکرد هوش مصنوعی
    return '
    <div id="meetingai-container" style="width: 100%; height: 90vh; overflow: hidden; border-radius: 24px; box-shadow: 0 20px 50px rgba(0,0,0,0.1); background: #fff;">
        <iframe 
            src="' . esc_url($plugin_url . 'index.html') . '" 
            style="width: 100%; height: 100%; border: none;" 
            allow="microphone; camera; display-capture; autoplay; clipboard-write;"
            sandbox="allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"
        ></iframe>
    </div>';
});
?>