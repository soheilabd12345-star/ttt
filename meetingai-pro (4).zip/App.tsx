
import React, { useState, useEffect, useRef } from 'react';
import Layout from './components/Layout';
import { AppView, MeetingSession, Group, Speaker, SubTopic, WordPressConfig, UserProfile, ActionItem } from './types';
import { 
  Plus, Trash2, Mail, Share2, ArrowRight, CheckCircle2, ListTodo, Calendar, 
  Camera, Mic, Key, ExternalLink, Sparkles, Send, MessageSquare, BarChart3, 
  Clock, UserPlus, X, Users, AlertCircle, ShieldAlert, Globe, Code, 
  Settings as SettingsIcon, Image as ImageIcon, Upload, Search, FileText, 
  UserCircle, Tag, Lock, ShieldCheck, Briefcase, Database, Check, Edit3, 
  User, LogOut, Link as LinkIcon, Download, SendHorizontal, Play, Pause, Volume2, FileDown,
  LayoutGrid, Copy, RefreshCw, Smartphone, Layers, Shield
} from 'lucide-react';
import { 
  generateMeetingInsights, processMeetingAudio, scanAndRedesignBoard, 
  generateProfessionalImage, chatWithSession, isKeyError 
} from './services/geminiService';
import { syncSessionToWordPress, fetchSessionsFromWordPress } from './services/wordpressService';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('home');
  const [user, setUser] = useState<UserProfile>({
    name: 'Executive Manager',
    email: 'admin@meetingai.pro',
    role: 'Managing Director',
    plan: 'Enterprise Pro'
  });

  const [sessions, setSessions] = useState<MeetingSession[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [wpConfig, setWpConfig] = useState<WordPressConfig>({
    siteUrl: window.location.origin,
    username: '',
    appPassword: '',
    isConnected: false
  });

  const [selectedSession, setSelectedSession] = useState<MeetingSession | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');
  const [hasApiKey, setHasApiKey] = useState(false);
  
  const [externalApiToken, setExternalApiToken] = useState(localStorage.getItem('external_api_token') || 'MAI-' + Math.random().toString(36).substring(2, 11).toUpperCase());

  // Modal States
  const [showSetup, setShowSetup] = useState(false);
  const [showTeamModal, setShowTeamModal] = useState(false);
  
  // New Team Form
  const [teamForm, setTeamForm] = useState({ name: '', members: '' });
  
  // Recording Session Setup
  const [setupData, setSetupData] = useState({ title: '', category: 'Strategic', description: '', assignedGroupId: '' });

  // Chat State
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Audio Player State
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Visuals
  const [scanImage, setScanImage] = useState<string | null>(null);
  const [redesignedImage, setRedesignedImage] = useState<string | null>(null);
  const [vizPrompt, setVizPrompt] = useState('');
  const [generatedImg, setGeneratedImg] = useState<string | null>(null);

  useEffect(() => {
    checkApiKey();
    
    const savedWp = localStorage.getItem('wp_config');
    if (savedWp) {
      const parsed = JSON.parse(savedWp);
      setWpConfig(parsed);
      if (parsed.isConnected) loadSessionsFromWP(parsed);
    }
    
    const savedGroups = localStorage.getItem('meetingai_groups');
    if (savedGroups) {
      setGroups(JSON.parse(savedGroups));
    }

    const savedSessions = localStorage.getItem('meetingai_local_sessions');
    if (savedSessions) setSessions(JSON.parse(savedSessions));
    
    if (!localStorage.getItem('external_api_token')) {
        localStorage.setItem('external_api_token', externalApiToken);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('meetingai_local_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('meetingai_groups', JSON.stringify(groups));
  }, [groups]);

  const loadSessionsFromWP = async (config: WordPressConfig) => {
    const wpSessions = await fetchSessionsFromWordPress(config);
    if (wpSessions.length > 0) setSessions(wpSessions);
  };

  const checkApiKey = async () => {
    if (window.aistudio && typeof window.aistudio.hasSelectedApiKey === 'function') {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      setHasApiKey(hasKey);
    } else {
      setHasApiKey(true);
    }
  };

  const openKeySelector = async () => {
    if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    }
  };

  const handleError = async (error: any) => {
    if (isKeyError(error)) {
      setHasApiKey(false);
      await openKeySelector();
    } else {
      alert("Intelligence Core Error: " + (error?.message || "Communication Failed"));
    }
  };

  const handleCreateTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teamForm.name.trim()) return;
    
    const newGroup: Group = {
      id: Date.now().toString(),
      name: teamForm.name,
      members: teamForm.members.split(',').map(m => m.trim()).filter(m => m),
      sessionIds: []
    };
    
    setGroups(prev => [...prev, newGroup]);
    setTeamForm({ name: '', members: '' });
    setShowTeamModal(false);
  };

  const startRecordingFlow = () => setShowSetup(true);

  const initiateRecording = async () => {
    setShowSetup(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = async () => {
          const base64Audio = reader.result as string;
          setIsProcessing(true);
          setProcessingStatus('Analyzing Strategic Dialogue...');
          try {
            const transcript = await processMeetingAudio(base64Audio.split(',')[1]);
            
            // Validation: Only proceed if actual speech was detected
            if (!transcript || transcript.trim().length === 0) {
              alert("No audible speech detected. Session recording cancelled to avoid empty files.");
              setIsProcessing(false);
              return;
            }

            const insights = await generateMeetingInsights(transcript);
            if (!insights) {
              alert("Failed to extract intelligence from recording.");
              setIsProcessing(false);
              return;
            }

            const newSession: MeetingSession = {
              id: Date.now().toString(),
              title: setupData.title || `Executive Session ${new Date().toLocaleDateString()}`,
              description: setupData.description,
              category: setupData.category,
              date: new Date().toISOString(),
              transcript,
              summary: insights.summary,
              mainTopic: insights.mainTopic,
              subTopics: insights.subTopics,
              speakers: insights.speakers,
              mainSpeakerId: insights.mainSpeakerId,
              actionItems: (insights.actionItems || []).map((it: any, i: number) => ({ id: i.toString(), task: it.task, status: 'pending' })),
              assignments: insights.assignments || [],
              scannedImages: [],
              chatHistory: [],
              audioData: base64Audio,
              groupId: setupData.assignedGroupId
            };

            if (setupData.assignedGroupId) {
              setGroups(prev => prev.map(g => g.id === setupData.assignedGroupId ? { ...g, sessionIds: [...g.sessionIds, newSession.id] } : g));
            }

            setSessions(prev => [newSession, ...prev]);
            setSelectedSession(newSession);
            setView('detail');
          } catch (err) { handleError(err); } finally { setIsProcessing(false); }
        };
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    } catch (err) { alert("Microphone permissions required for audio analysis."); }
  };

  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
    }
  };

  const handleSendMessage = async () => {
    if (!chatInput.trim() || !selectedSession) return;
    const msg = chatInput;
    setChatInput('');
    const history = selectedSession.chatHistory || [];
    setSelectedSession({ ...selectedSession, chatHistory: [...history, { role: 'user', text: msg }] });
    try {
      const response = await chatWithSession(selectedSession.transcript, msg, history);
      const updated = { ...selectedSession, chatHistory: [...history, { role: 'user', text: msg }, { role: 'model', text: response }] };
      setSelectedSession(updated);
      setSessions(prev => prev.map(s => s.id === updated.id ? updated : s));
    } catch (err) { handleError(err); }
  };

  const handleScanUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setScanImage(base64);
      setIsProcessing(true);
      setProcessingStatus('Digitizing Workspace Assets...');
      try {
        const result = await scanAndRedesignBoard(base64.split(',')[1]);
        setRedesignedImage(result);
      } catch (err) { handleError(err); } finally { setIsProcessing(false); }
    };
    reader.readAsDataURL(file);
  };

  const handleVizGenerate = async () => {
    if (!vizPrompt.trim()) return;
    setIsProcessing(true);
    setProcessingStatus('Visualizing Strategic Concepts...');
    try {
      const result = await generateProfessionalImage(vizPrompt);
      setGeneratedImg(result);
    } catch (err) { handleError(err); } finally { setIsProcessing(false); }
  };

  const regenerateExternalToken = () => {
    const newToken = 'MAI-' + Math.random().toString(36).substring(2, 11).toUpperCase();
    setExternalApiToken(newToken);
    localStorage.setItem('external_api_token', newToken);
  };

  return (
    <div dir="ltr" className="antialiased text-slate-900">
      <Layout activeView={view} setView={setView} user={user}>
        {isProcessing && (
          <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-3xl z-[200] flex flex-col items-center justify-center text-white">
            <div className="relative mb-10">
              <div className="w-40 h-40 border-8 border-white/5 border-t-indigo-500 rounded-full animate-spin"></div>
              <Sparkles className="absolute inset-0 m-auto text-indigo-400 animate-pulse" size={64} />
            </div>
            <h3 className="text-4xl font-black text-center px-6 tracking-tighter uppercase italic">{processingStatus}</h3>
            <p className="text-indigo-200/40 mt-8 text-center tracking-[0.6em] text-xs uppercase font-black">AI Orchestration Active</p>
          </div>
        )}

        {/* TEAM CREATION MODAL */}
        {showTeamModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-2xl z-[150] flex items-center justify-center p-6">
            <form onSubmit={handleCreateTeam} className="bg-white w-full max-w-lg rounded-[4rem] p-12 space-y-8 animate-in zoom-in-95 duration-500 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600"></div>
               <div className="flex justify-between items-center">
                  <h2 className="text-4xl font-black text-slate-900 tracking-tighter">New Strategic Squad</h2>
                  <button type="button" onClick={() => setShowTeamModal(false)} className="p-3 bg-slate-50 text-slate-400 rounded-2xl hover:bg-slate-100"><X /></button>
               </div>
               <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Squad Designation</label>
                    <input 
                      required
                      value={teamForm.name} 
                      onChange={e => setTeamForm({...teamForm, name: e.target.value})} 
                      placeholder="e.g., Executive Board, DevOps Intelligence" 
                      className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-[2rem] font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all text-xl" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Assigned Nodes (Members)</label>
                    <textarea 
                      value={teamForm.members} 
                      onChange={e => setTeamForm({...teamForm, members: e.target.value})} 
                      placeholder="Enter names separated by commas..." 
                      className="w-full h-32 px-8 py-5 bg-slate-50 border border-slate-100 rounded-[2rem] font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all resize-none" 
                    />
                  </div>
               </div>
               <div className="pt-4">
                  <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black text-xl shadow-2xl shadow-indigo-600/30 hover:scale-[1.02] active:scale-95 transition-all">Establish Squad Nodes</button>
               </div>
            </form>
          </div>
        )}

        {/* SESSION SETUP MODAL */}
        {showSetup && (
          <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-3xl z-[150] flex items-center justify-center p-6">
            <div className="bg-white w-full max-w-2xl rounded-[4rem] p-14 space-y-10 animate-in slide-in-from-bottom-10 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-emerald-500 to-indigo-600"></div>
               <div className="space-y-2">
                  <h2 className="text-5xl font-black text-slate-900 tracking-tighter uppercase italic">Ready to Capture</h2>
                  <p className="text-slate-500 font-bold text-lg">Define the intelligence scope for this session</p>
               </div>
               <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Session Title</label>
                    <input value={setupData.title} onChange={e => setSetupData({...setupData, title: e.target.value})} placeholder="e.g., Strategic Board Meeting Q3" className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-[2rem] font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all text-2xl" />
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                     <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Classification</label>
                       <select value={setupData.category} onChange={e => setSetupData({...setupData, category: e.target.value})} className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-[2rem] font-bold outline-none appearance-none cursor-pointer">
                          <option>Strategic</option>
                          <option>Operational</option>
                          <option>Executive</option>
                          <option>Technical</option>
                       </select>
                     </div>
                     <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Squad Context</label>
                       <select value={setupData.assignedGroupId} onChange={e => setSetupData({...setupData, assignedGroupId: e.target.value})} className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-[2rem] font-bold outline-none appearance-none cursor-pointer">
                          <option value="">Personal Intelligence</option>
                          {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                       </select>
                     </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Context Briefing</label>
                    <textarea value={setupData.description} onChange={e => setSetupData({...setupData, description: e.target.value})} placeholder="What are we analyzing today?" className="w-full h-32 px-8 py-5 bg-slate-50 border border-slate-100 rounded-[2rem] font-bold outline-none resize-none" />
                  </div>
               </div>
               <div className="flex gap-6">
                  <button onClick={initiateRecording} className="flex-1 py-7 bg-indigo-600 text-white rounded-[2.5rem] font-black text-2xl shadow-2xl shadow-indigo-600/30 flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-95 transition-all">
                    <Mic size={32} /> Initialize Neural Capture
                  </button>
                  <button onClick={() => setShowSetup(false)} className="px-12 py-7 bg-slate-100 text-slate-600 rounded-[2.5rem] font-black text-xl hover:bg-slate-200">Cancel</button>
               </div>
            </div>
          </div>
        )}

        {view === 'home' && (
          <div className="p-8 md:p-12 max-w-7xl mx-auto space-y-16">
            <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10 border-b pb-12 border-slate-200/50">
              <div className="space-y-2">
                <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase italic">Control Center</h2>
                <div className="flex items-center gap-4">
                  <div className="px-4 py-1.5 bg-emerald-50 text-emerald-600 rounded-full flex items-center gap-2 border border-emerald-100">
                    <Shield size={14} className="fill-emerald-600" />
                    <span className="text-[10px] font-black uppercase tracking-widest">End-to-End Encryption Enabled</span>
                  </div>
                  <div className="px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-full flex items-center gap-2 border border-indigo-100">
                    <Layers size={14} />
                    <span className="text-[10px] font-black uppercase tracking-widest">{user.plan} Active</span>
                  </div>
                </div>
              </div>
              <button onClick={startRecordingFlow} className="bg-indigo-600 text-white px-12 py-6 rounded-[2.5rem] font-black text-xl shadow-2xl shadow-indigo-600/40 hover:bg-indigo-700 transition-all flex items-center gap-4 group">
                <Plus size={24} className="group-hover:rotate-90 transition-transform duration-500" /> New Intelligence Log
              </button>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              {[
                { label: 'Intelligence Vault', val: sessions.length, icon: Mic, color: 'indigo' },
                { label: 'Neural Extractions', val: sessions.reduce((a, s) => a + s.actionItems.length, 0), icon: ListTodo, color: 'emerald' },
                { label: 'Strategic Squads', val: groups.length, icon: Users, color: 'amber' }
              ].map((stat, i) => (
                <div key={i} className="bg-white p-12 rounded-[4rem] border border-slate-100 shadow-sm flex items-center justify-between group hover:shadow-2xl hover:-translate-y-1 transition-all duration-500">
                  <div className="text-left">
                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{stat.label}</p>
                     <p className="text-6xl font-black text-slate-800 tracking-tighter">{stat.val}</p>
                  </div>
                  <div className={`p-8 bg-${stat.color}-50 text-${stat.color}-600 rounded-[2rem] group-hover:scale-110 transition-transform`}>
                     <stat.icon size={48} />
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-10">
              <div className="flex items-center justify-between">
                 <h3 className="text-4xl font-black text-slate-800 tracking-tight uppercase italic">Intelligence Archive</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                {sessions.length === 0 ? (
                  <div className="col-span-full py-48 flex flex-col items-center justify-center space-y-6 opacity-20 text-center grayscale group hover:grayscale-0 transition-all">
                     <BarChart3 size={120} className="text-indigo-300 group-hover:scale-110 transition-transform" />
                     <p className="text-2xl font-black italic tracking-widest">Strategic database initialized. Awaiting input logs.</p>
                  </div>
                ) : (
                  sessions.map(s => (
                    <div key={s.id} onClick={() => { setSelectedSession(s); setView('detail'); }} className="group bg-white p-12 rounded-[4.5rem] border border-slate-100 hover:border-indigo-500 cursor-pointer transition-all duration-500 shadow-sm hover:shadow-2xl text-left relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50/20 rounded-full -mr-16 -mt-16 blur-2xl group-hover:scale-150 transition-transform"></div>
                      <div className="flex justify-between items-start mb-8 relative">
                         <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-5 py-2 rounded-full uppercase tracking-tighter border border-indigo-100">{s.category}</span>
                         <p className="text-[10px] font-bold text-slate-400">{new Date(s.date).toLocaleDateString()}</p>
                      </div>
                      <h4 className="text-3xl font-black text-slate-800 mb-6 truncate group-hover:text-indigo-600 transition-colors uppercase tracking-tighter italic leading-none">{s.title}</h4>
                      <p className="text-slate-500 text-sm leading-relaxed line-clamp-3 mb-10 font-medium">{s.summary}</p>
                      <div className="flex justify-between items-center border-t pt-8 border-slate-50 relative">
                         <div className="flex -space-x-4">
                            {s.speakers.slice(0, 3).map((_, i) => <div key={i} className="w-12 h-12 rounded-full bg-slate-100 border-4 border-white flex items-center justify-center text-[10px] font-black shadow-inner">SP</div>)}
                            {s.speakers.length > 3 && <div className="w-12 h-12 rounded-full bg-indigo-50 border-4 border-white flex items-center justify-center text-[10px] font-black">+{s.speakers.length - 3}</div>}
                         </div>
                         {s.audioData && <div className="p-3 bg-indigo-600 text-white rounded-2xl animate-pulse shadow-xl shadow-indigo-600/30"><Volume2 size={20} /></div>}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {view === 'groups' && (
          <div className="p-8 md:p-12 max-w-7xl mx-auto space-y-16">
             <header className="flex justify-between items-center border-b pb-12 border-slate-200/50">
                <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase italic">Strategic Squads</h2>
                <button onClick={() => setShowTeamModal(true)} className="p-6 bg-indigo-600 text-white rounded-[2rem] shadow-2xl shadow-indigo-600/40 hover:scale-110 transition-all active:scale-95"><Plus size={32} /></button>
             </header>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
                {groups.length === 0 ? (
                  <div className="col-span-full py-60 flex flex-col items-center justify-center space-y-8 opacity-20 text-center grayscale">
                     <Users size={140} className="text-indigo-200" />
                     <p className="text-3xl font-black italic tracking-widest uppercase">No operational squads founded yet.</p>
                  </div>
                ) : groups.map(g => (
                  <div key={g.id} className="bg-white p-14 rounded-[4.5rem] border border-slate-100 shadow-xl flex flex-col gap-12 group hover:border-indigo-400 transition-all duration-500 text-left">
                     <div className="flex justify-between items-center">
                        <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">{g.name}</h3>
                        <div className="p-6 bg-indigo-50 text-indigo-600 rounded-[2rem] group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-inner"><Users size={32} /></div>
                     </div>
                     <div className="space-y-8">
                        <div className="flex items-center gap-4">
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-l-4 border-indigo-200 pl-4">Collaborative Vault ({g.sessionIds.length})</p>
                        </div>
                        <div className="space-y-4">
                           {g.sessionIds.length === 0 ? <p className="text-sm font-bold text-slate-300 italic">No shared intelligence logs found</p> : 
                            g.sessionIds.map(sid => {
                               const session = sessions.find(s => s.id === sid);
                               return (
                                 <div key={sid} onClick={() => { setSelectedSession(session!); setView('detail'); }} className="p-5 bg-slate-50 rounded-[1.5rem] flex items-center gap-4 cursor-pointer hover:bg-indigo-50 transition-all group/item">
                                    <FileText size={18} className="text-indigo-600 group-hover/item:scale-110 transition-transform" />
                                    <p className="font-black truncate uppercase text-xs tracking-tight">{session?.title}</p>
                                 </div>
                               );
                            })
                           }
                        </div>
                     </div>
                     <div className="flex justify-between items-center border-t pt-10 border-slate-50 mt-auto">
                        <div className="flex -space-x-4">
                           {g.members.length === 0 ? <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">No Node Assigned</span> : g.members.map((m, i) => (
                             <div key={i} title={m} className="w-14 h-14 rounded-full bg-slate-100 border-4 border-white flex items-center justify-center text-xs font-black uppercase shadow-sm">
                                {m.substring(0, 2)}
                             </div>
                           ))}
                        </div>
                        <button className="p-4 bg-slate-100 rounded-[1.2rem] text-slate-400 hover:bg-indigo-600 hover:text-white transition-all shadow-sm"><Plus size={24} /></button>
                     </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {view === 'settings' && (
          <div className="p-8 md:p-12 max-w-5xl mx-auto space-y-16 text-left">
             <header className="space-y-4">
                <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase italic">Control Panel</h2>
                <p className="text-slate-500 font-bold text-xl max-w-2xl leading-relaxed">System architecture management, neural gateway authentication, and developer integration portal.</p>
             </header>
             <div className="space-y-16">
                <section className="bg-white p-14 rounded-[4.5rem] border border-slate-100 shadow-2xl relative overflow-hidden">
                   <h3 className="text-3xl font-black mb-10 flex items-center gap-5 border-b pb-8 uppercase tracking-tighter"><Database size={32} className="text-indigo-600" /> Cloud Sync Gateway</h3>
                   <div className="space-y-10">
                      <div className="p-10 bg-blue-50/50 text-blue-900 rounded-[3rem] text-lg font-bold flex items-center gap-6 border border-blue-100/50 italic leading-relaxed">
                         <ShieldCheck size={48} className="text-blue-600 shrink-0" /> Encrypted link active. Data tunneled to WordPress.
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <input value={wpConfig.siteUrl} onChange={e => setWpConfig({...wpConfig, siteUrl: e.target.value})} placeholder="Gateway Base URL" className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-2xl font-black outline-none focus:ring-4 focus:ring-blue-500/10" />
                        <input value={wpConfig.username} onChange={e => setWpConfig({...wpConfig, username: e.target.value})} placeholder="Intelligence ID" className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-2xl font-black outline-none focus:ring-4 focus:ring-blue-500/10" />
                      </div>
                      <input type="password" value={wpConfig.appPassword} onChange={e => setWpConfig({...wpConfig, appPassword: e.target.value})} placeholder="Application Secret Key" className="w-full px-8 py-5 bg-slate-50 border border-slate-100 rounded-2xl font-black outline-none focus:ring-4 focus:ring-blue-500/10" />
                      <button onClick={() => { localStorage.setItem('wp_config', JSON.stringify({...wpConfig, isConnected: true})); setWpConfig({...wpConfig, isConnected: true}); alert("Gateway Link Established"); }} className="w-full py-7 bg-indigo-600 text-white rounded-[2.5rem] font-black text-2xl shadow-2xl shadow-indigo-600/30">Establish Intelligence Bridge</button>
                   </div>
                </section>

                <section className="bg-white p-14 rounded-[4.5rem] border border-slate-100 shadow-2xl relative overflow-hidden">
                   <h3 className="text-3xl font-black mb-10 flex items-center gap-5 border-b pb-8 uppercase tracking-tighter"><Key size={32} className="text-indigo-600" /> AI Core Integration</h3>
                   <div className="space-y-10">
                      <button onClick={openKeySelector} className={`w-full py-10 rounded-[3rem] font-black text-2xl flex items-center justify-center gap-6 border-4 transition-all ${hasApiKey ? 'border-emerald-100 bg-emerald-50 text-emerald-700 shadow-2xl shadow-emerald-500/10' : 'border-red-100 bg-red-50 text-red-700 shadow-2xl shadow-red-500/10'}`}>
                         {hasApiKey ? <ShieldCheck size={40} className="fill-emerald-100" /> : <AlertCircle size={40} />}
                         {hasApiKey ? 'Neural Engine Status: ONLINE' : 'System Interrupted: Neural Authentication Required'}
                      </button>
                   </div>
                </section>

                <section className="bg-slate-900 p-16 rounded-[5rem] text-white shadow-3xl relative overflow-hidden group">
                   <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-[120px] -mr-48 -mt-48 transition-all group-hover:scale-150"></div>
                   <div className="relative z-10 space-y-12">
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                        <div className="space-y-2">
                           <h3 className="text-4xl font-black tracking-tighter flex items-center gap-4 italic uppercase"><Smartphone size={36} className="text-indigo-400" /> External App Bridge</h3>
                           <p className="text-slate-400 font-bold max-w-xl">Enable third-party applications or automated workflows to securely access your MeetingAI database.</p>
                        </div>
                      </div>

                      <div className="bg-white/5 border border-white/10 p-10 rounded-[3rem] flex flex-col md:flex-row items-center justify-between gap-10 hover:border-indigo-500/50 transition-all">
                          <div className="space-y-3 w-full">
                             <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.4em]">Integration Secret Token</span>
                             <div className="flex items-center gap-4">
                                <code className="text-indigo-300 font-black text-3xl tracking-[0.2em] break-all">{externalApiToken}</code>
                                <button onClick={() => { navigator.clipboard.writeText(externalApiToken); alert("Token copied to secure clipboard."); }} className="p-4 bg-white/10 rounded-2xl text-white hover:bg-white/20 transition-all"><Copy size={20} /></button>
                             </div>
                          </div>
                          <button onClick={regenerateExternalToken} className="px-10 py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black flex items-center gap-3 hover:bg-indigo-500 transition-all shadow-2xl shadow-indigo-600/30"><RefreshCw size={20} /> Rotate Token</button>
                      </div>
                   </div>
                </section>

                <button onClick={() => { localStorage.clear(); window.location.reload(); }} className="w-full py-8 bg-red-50 text-red-600 rounded-[3rem] font-black text-2xl border border-red-100 flex items-center justify-center gap-5 hover:bg-red-100 transition-all shadow-sm uppercase tracking-widest italic">
                   <LogOut size={32} /> Wipe Environmental Data & Logout
                </button>
             </div>
          </div>
        )}

        {view === 'detail' && selectedSession && (
          <div className="p-8 md:p-12 max-w-7xl mx-auto space-y-16 animate-in fade-in pb-32 text-left">
            <button onClick={() => setView('home')} className="text-indigo-600 font-black flex items-center gap-3 group text-sm uppercase tracking-widest">
              <ArrowRight className="rotate-180 group-hover:-translate-x-2 transition-transform" /> Exit to Intelligence Archive
            </button>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
              <div className="lg:col-span-2 space-y-12">
                <section className="bg-white p-14 rounded-[4.5rem] border border-slate-100 shadow-2xl relative overflow-hidden">
                   <h2 className="text-5xl font-black text-slate-900 mb-10 tracking-tighter italic uppercase">{selectedSession.title}</h2>
                   <div className="space-y-8">
                     <div className="p-8 bg-slate-50 border border-slate-100 rounded-[2.5rem]">
                       <h4 className="text-xs font-black text-indigo-600 uppercase tracking-widest mb-4">Strategic Summary</h4>
                       <p className="text-2xl font-medium text-slate-700 italic leading-relaxed">"{selectedSession.summary}"</p>
                     </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                           <h4 className="text-sm font-black uppercase tracking-widest border-l-4 border-indigo-600 pl-4">Core Topics</h4>
                           <div className="space-y-4">
                              {selectedSession.subTopics.map((st, i) => (
                                <div key={i} className="p-6 bg-slate-50 rounded-3xl">
                                   <p className="font-black text-slate-900 mb-2 uppercase text-xs">{st.title}</p>
                                   <p className="text-xs text-slate-500">{st.summary}</p>
                                </div>
                              ))}
                           </div>
                        </div>
                        <div className="space-y-6">
                           <h4 className="text-sm font-black uppercase tracking-widest border-l-4 border-emerald-600 pl-4">Active Participants</h4>
                           <div className="space-y-4">
                              {selectedSession.speakers.map((sp, i) => (
                                <div key={i} className="p-6 bg-white border border-slate-100 rounded-3xl flex justify-between items-center">
                                   <div>
                                      <p className="font-black text-slate-900">{sp.name}</p>
                                      <p className="text-[10px] font-bold text-slate-400 uppercase">{sp.role}</p>
                                   </div>
                                   <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-xl shadow-emerald-500/50"></div>
                                </div>
                              ))}
                           </div>
                        </div>
                     </div>
                   </div>
                </section>
                <section className="bg-slate-950 p-12 rounded-[4.5rem] text-white space-y-10 shadow-3xl">
                   <div className="flex items-center justify-between">
                      <h3 className="text-4xl font-black italic uppercase flex items-center gap-4"><Sparkles className="text-indigo-400" /> Neural Assistant</h3>
                   </div>
                   <div className="h-[400px] overflow-y-auto space-y-8 px-4 custom-scrollbar">
                      {(selectedSession.chatHistory || []).length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center space-y-6 opacity-20 text-center grayscale">
                           <MessageSquare size={80} />
                           <p className="text-2xl font-black tracking-widest">Ask me anything about the dialogue.</p>
                        </div>
                      ) : (
                        selectedSession.chatHistory?.map((msg, i) => (
                          <div key={i} className={`flex ${msg.role === 'model' ? 'justify-start' : 'justify-end'}`}>
                             <div className={`max-w-[85%] p-7 rounded-[2.5rem] text-lg ${msg.role === 'model' ? 'bg-slate-900 text-slate-300' : 'bg-indigo-600 text-white'}`}>
                                {msg.text}
                             </div>
                          </div>
                        ))
                      )}
                      <div ref={chatEndRef} />
                   </div>
                   <div className="relative">
                      <input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendMessage()} placeholder="Extract specific insights..." className="w-full px-10 py-7 bg-white/5 border border-white/10 rounded-[2.5rem] outline-none text-2xl font-black" />
                      <button onClick={handleSendMessage} className="absolute right-6 top-1/2 -translate-y-1/2 p-5 bg-indigo-600 rounded-3xl"><Send /></button>
                   </div>
                </section>
              </div>
              <aside className="space-y-12">
                 <div className="bg-white p-12 rounded-[4rem] border border-slate-100 shadow-xl">
                    <h3 className="text-xl font-black mb-8 border-b pb-6 uppercase tracking-widest text-xs">Roadmap Tasks</h3>
                    <div className="space-y-6">
                       {selectedSession.actionItems.map((ai, i) => (
                         <div key={i} className="flex items-start gap-4 p-6 bg-slate-50 rounded-3xl border border-slate-100 group hover:bg-white transition-all">
                            <div className="w-7 h-7 rounded-xl border-2 border-indigo-200 mt-1 group-hover:bg-indigo-600 group-hover:border-indigo-600 transition-all"></div>
                            <p className="text-sm font-black text-slate-700 leading-tight">{ai.task}</p>
                         </div>
                       ))}
                    </div>
                 </div>
              </aside>
            </div>
          </div>
        )}

        {view === 'record' && (
          <div className="p-10 flex flex-col items-center justify-center min-h-[85vh] space-y-20 animate-in fade-in">
             <div className="text-center space-y-8">
                <h2 className="text-8xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">Capture Core</h2>
                <p className="text-slate-500 max-w-2xl mx-auto font-bold text-2xl leading-relaxed italic">Neural processing and strategic context mapping is live.</p>
             </div>
             <div className="relative group scale-110">
                <div className={`absolute inset-0 rounded-full blur-[100px] opacity-20 transition-all duration-1000 ${isRecording ? 'bg-red-600 animate-pulse' : 'bg-indigo-600'}`}></div>
                <button 
                  onClick={isRecording ? stopRecording : startRecordingFlow}
                  className={`relative z-10 w-80 h-80 rounded-full flex items-center justify-center shadow-3xl transition-all transform hover:scale-105 active:scale-95 ${isRecording ? 'bg-red-600' : 'bg-indigo-600'} text-white`}
                >
                   {isRecording ? <div className="w-28 h-28 bg-white rounded-[2.5rem] animate-pulse"></div> : <Mic size={140} />}
                </button>
             </div>
             <p className={`text-4xl font-black tracking-[0.5em] uppercase italic ${isRecording ? 'text-red-600 animate-pulse' : 'text-slate-300'}`}>
                {isRecording ? 'Synthesizing...' : 'Awaiting Signals'}
             </p>
          </div>
        )}

        {view === 'scan' && (
          <div className="p-8 md:p-12 max-w-7xl mx-auto space-y-16">
             <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase italic">Board Digitizer</h2>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                <div className="bg-white p-16 rounded-[5rem] border-4 border-dashed border-slate-100 flex flex-col items-center justify-center gap-10 hover:border-indigo-500/30 transition-all cursor-pointer group relative shadow-sm">
                   <input type="file" id="board-scan" className="hidden" accept="image/*" onChange={handleScanUpload} />
                   <label htmlFor="board-scan" className="flex flex-col items-center gap-8 cursor-pointer text-center">
                      <div className="p-12 bg-indigo-50 text-indigo-600 rounded-[3.5rem] shadow-2xl group-hover:scale-110 transition-transform"><ImageIcon size={96} /></div>
                      <p className="text-3xl font-black text-slate-800">Visual Workspace Feed</p>
                   </label>
                   {scanImage && <img src={scanImage} className="w-full h-96 object-cover rounded-[4rem] border-8 border-white shadow-3xl mt-6" alt="Original Feed" />}
                </div>
                <div className="bg-slate-950 p-16 rounded-[5rem] text-white flex flex-col items-center justify-center shadow-3xl relative overflow-hidden">
                   {redesignedImage ? (
                     <div className="space-y-12 w-full relative z-10">
                        <img src={redesignedImage} className="w-full h-[550px] object-contain rounded-[4rem] shadow-3xl bg-slate-900/50 p-4" alt="Digitized Asset" />
                        <button className="w-full py-5 bg-white text-slate-900 rounded-[2rem] font-black text-lg">Archive Digitized Node</button>
                     </div>
                   ) : (
                     <div className="text-center space-y-10 opacity-10 italic">
                        <Sparkles size={160} className="mx-auto" />
                        <p className="text-4xl font-black tracking-[0.3em] uppercase">Awaiting Image Feed</p>
                     </div>
                   )}
                </div>
             </div>
          </div>
        )}

        {view === 'generate' && (
          <div className="p-8 md:p-12 max-w-5xl mx-auto space-y-16 text-left">
             <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase italic text-left">Strategic Visualizer</h2>
             <div className="bg-white p-16 rounded-[5rem] border border-slate-100 shadow-3xl relative overflow-hidden">
                <div className="space-y-8 mb-12">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-l-4 border-indigo-600 pl-4 ml-1">Synthesis Description</label>
                   <textarea value={vizPrompt} onChange={e => setVizPrompt(e.target.value)} placeholder="Describe a strategic process diagram or minimalist artwork..." className="w-full h-56 px-10 py-10 bg-slate-50 border border-slate-100 rounded-[3.5rem] font-black text-3xl outline-none resize-none shadow-inner tracking-tighter" />
                </div>
                <button onClick={handleVizGenerate} className="w-full py-10 bg-indigo-600 text-white rounded-[3rem] font-black text-3xl shadow-3xl shadow-indigo-600/40">Synthesize Professional Graphic</button>
                {generatedImg && (
                  <div className="pt-24 mt-20 relative">
                     <img src={generatedImg} className="w-full rounded-[5rem] shadow-3xl border-[16px] border-white" alt="Synthesized Asset" />
                  </div>
                )}
             </div>
          </div>
        )}
      </Layout>
    </div>
  );
};

export default App;
