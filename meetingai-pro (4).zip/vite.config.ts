import { defineConfig } from 'vite';

export default defineConfig({
  // If deploying to username.github.io/repo-name/, set base to '/repo-name/'
  // For custom domains, keep it '/'
  base: './', 
  define: {
    'process.env.API_KEY': JSON.stringify(process.env.API_KEY)
  },
  build: {
    outDir: 'dist',
    target: 'esnext'
  }
});