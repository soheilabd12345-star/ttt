
import React from 'react';
import { Home, Mic, Camera, Users, Settings, Sparkles, LogOut } from 'lucide-react';
import { AppView, UserProfile } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeView: AppView;
  setView: (view: AppView) => void;
  user: UserProfile;
}

const Layout: React.FC<LayoutProps> = ({ children, activeView, setView, user }) => {
  const navItems = [
    { id: 'home', icon: Home, label: 'Dashboard' },
    { id: 'record', icon: Mic, label: 'Record Session' },
    { id: 'scan', icon: Camera, label: 'AI Scan' },
    { id: 'generate', icon: Sparkles, label: 'Visualizer' },
    { id: 'groups', icon: Users, label: 'Teams' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#F8FAFC] font-sans">
      {/* Sidebar for Desktop */}
      <nav className="hidden md:flex flex-col w-72 bg-white border-r border-slate-200 h-screen sticky top-0 shadow-sm text-left">
        <div className="p-8 border-b border-slate-100 flex justify-start">
          <h1 className="text-2xl font-black text-indigo-600 tracking-tighter flex items-center gap-2">
            <Sparkles className="fill-indigo-600" size={24} /> MeetingAI <span className="text-slate-400 font-light">Pro</span>
          </h1>
        </div>
        <div className="flex-1 p-6 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id as AppView)}
              className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl transition-all duration-200 ${
                activeView === item.id 
                  ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' 
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-4">
                <item.icon size={22} strokeWidth={activeView === item.id ? 2.5 : 2} />
                <span className="font-bold tracking-tight">{item.label}</span>
              </div>
            </button>
          ))}
        </div>
        <div className="p-6 border-t border-slate-100 space-y-4">
          <div className="bg-slate-50 rounded-2xl p-4 flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold border border-indigo-200">
              {getInitials(user.name)}
            </div>
            <div className="flex-1 min-w-0 text-left pl-3">
              <p className="text-sm font-bold text-slate-800 truncate">{user.name}</p>
              <p className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">{user.plan}</p>
            </div>
          </div>
          <button 
            onClick={() => { localStorage.clear(); window.location.reload(); }} 
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-slate-100 text-slate-400 hover:text-red-500 hover:bg-red-50 hover:border-red-100 transition-all font-bold text-xs"
          >
            <LogOut size={14} /> Log Out
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-24 md:pb-0 flex flex-col">
        <div className="flex-1">
          {children}
        </div>
        
        {/* Centered Footer */}
        <footer className="p-8 border-t border-slate-100 bg-white/50 backdrop-blur-sm flex justify-center items-center mt-auto">
          <p className="text-slate-500 text-sm font-bold text-center">
            Developed by Soheil Kargar Business Studio
          </p>
        </footer>
      </main>

      {/* Mobile Bottom Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t border-slate-200 flex justify-around items-center p-4 z-50">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as AppView)}
            className={`flex flex-col items-center space-y-1 p-2 transition-colors ${
              activeView === item.id ? 'text-indigo-600' : 'text-slate-400'
            }`}
          >
            <item.icon size={24} />
          </button>
        ))}
      </nav>
    </div>
  );
};

export default Layout;
