
import { MeetingSession, WordPressConfig } from "../types";

export const syncSessionToWordPress = async (session: MeetingSession, config: WordPressConfig) => {
  if (!config.isConnected || !config.siteUrl) return null;

  const auth = btoa(`${config.username}:${config.appPassword}`);
  const endpoint = `${config.siteUrl.replace(/\/$/, "")}/wp-json/wp/v2/meeting_session`;

  const payload = {
    title: session.title,
    status: 'publish',
    content: `<h3>Summary</h3><p>${session.summary}</p><h3>Transcript</h3><pre>${session.transcript}</pre>`,
    session_data: JSON.stringify({
      mainTopic: session.mainTopic,
      speakers: session.speakers,
      actionItems: session.actionItems,
      assignments: session.assignments
    })
  };

  try {
    const response = await fetch(session.wpId ? `${endpoint}/${session.wpId}` : endpoint, {
      method: session.wpId ? "PUT" : "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Basic ${auth}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error("WordPress sync failed");
    const data = await response.json();
    return data.id as number;
  } catch (error) {
    console.error("WP Sync Error:", error);
    return null;
  }
};

export const fetchSessionsFromWordPress = async (config: WordPressConfig): Promise<MeetingSession[]> => {
  if (!config.isConnected) return [];

  const auth = btoa(`${config.username}:${config.appPassword}`);
  const endpoint = `${config.siteUrl.replace(/\/$/, "")}/wp-json/wp/v2/meeting_session?_fields=id,title,date,session_data,content`;

  try {
    const response = await fetch(endpoint, {
      headers: { "Authorization": `Basic ${auth}` }
    });
    const data = await response.json();

    return data.map((post: any) => {
      const meta = post.session_data ? JSON.parse(post.session_data) : {};
      return {
        id: post.id.toString(),
        wpId: post.id,
        title: post.title.rendered,
        date: post.date,
        summary: post.content.rendered.split('</p>')[0].replace(/<[^>]*>/g, ''),
        mainTopic: meta.mainTopic || "Imported Session",
        speakers: meta.speakers || [],
        actionItems: meta.actionItems || [],
        assignments: meta.assignments || [],
        transcript: "", // Transcript might be large, handle with care
        subTopics: [],
        scannedImages: [],
        chatHistory: []
      };
    });
  } catch (error) {
    console.error("Fetch Error:", error);
    return [];
  }
};
