
import { GoogleGenAI, Type } from "@google/genai";

export const isKeyError = (error: any) => {
  const msg = error?.message?.toLowerCase() || "";
  return msg.includes("requested entity was not found") || 
         msg.includes("api_key_invalid") || 
         msg.includes("not authorized") ||
         msg.includes("permission denied") ||
         msg.includes("permission_denied") ||
         msg.includes("403") ||
         msg.includes("billing");
};

export const processMeetingAudio = async (base64Audio: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Audio, mimeType: 'audio/webm' } },
        { text: "Accurately transcribe this audio. Detect all distinct speakers (e.g., Speaker 1, Speaker 2). Label each turn with the speaker name. Detect the language automatically (Farsi/English). If there is no audible speech or only background noise, return exactly 'NO_SPEECH_DETECTED'. Do not provide any other text if no speech is found." }
      ]
    }
  });
  const text = response.text?.trim() || "";
  if (text === "NO_SPEECH_DETECTED") return "";
  return text;
};

export const generateMeetingInsights = async (transcript: string) => {
  if (!transcript || transcript.trim().length === 0) return null;
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this transcript with multiple speakers. 
    1. Identify the Main Topic and Sub-topics.
    2. Identify all speakers and their roles. Determine who the "Main Speaker" is.
    3. Detect the language and respond in that same language (Persian/English).
    Format the output as a clean JSON matching the specified schema.
    
    Transcript: ${transcript}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          mainTopic: { type: Type.STRING },
          summary: { type: Type.STRING },
          speakers: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                name: { type: Type.STRING },
                role: { type: Type.STRING },
                contribution: { type: Type.STRING }
              }
            }
          },
          mainSpeakerId: { type: Type.STRING },
          subTopics: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                summary: { type: Type.STRING },
                speakerId: { type: Type.STRING }
              }
            }
          },
          actionItems: {
            type: Type.ARRAY,
            items: { type: Type.OBJECT, properties: { task: { type: Type.STRING } } }
          },
          assignments: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                assignee: { type: Type.STRING },
                task: { type: Type.STRING },
                dueDate: { type: Type.STRING }
              }
            }
          }
        },
        required: ["mainTopic", "summary", "speakers", "subTopics", "actionItems", "assignments"]
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const chatWithSession = async (transcript: string, question: string, history: { role: 'user' | 'model'; text: string }[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const formattedContents = [
    { role: 'user', parts: [{ text: `Meeting transcript with multiple speakers: \n\n${transcript}` }] },
    { role: 'model', parts: [{ text: "I have analyzed the speakers and content. How can I help?" }] },
    ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] }))
  ];
  if (history.length === 0 || history[history.length - 1].text !== question) {
      formattedContents.push({ role: 'user', parts: [{ text: question }] });
  }
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: formattedContents,
    config: {
      systemInstruction: "You are an expert executive assistant. Answer questions based on the transcript and identified speakers. Be professional."
    }
  });
  return response.text || "I'm sorry, I couldn't generate a response.";
};

export const generateProfessionalImage = async (prompt: string, aspectRatio: "1:1" | "16:9" | "9:16" = "1:1", base64RefImage?: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const parts: any[] = [];
  if (base64RefImage) {
    parts.push({ inlineData: { data: base64RefImage, mimeType: 'image/jpeg' } });
    parts.push({ text: `Style match: ${prompt}. Professional, corporate.` });
  } else {
    parts.push({ text: `Professional graphic for: ${prompt}. Minimalist, 4k.` });
  }
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: parts },
    config: { imageConfig: { aspectRatio } }
  });
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("Failed to generate image.");
};

export const scanAndRedesignBoard = async (base64Image: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType: 'image/jpeg' } },
        { text: "Clean redesign of this whiteboard." }
      ]
    },
    config: { imageConfig: { aspectRatio: "3:4", imageSize: "1K" } }
  });
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  return '';
};
