# راهنمای دیپلوی MeetingAI Pro

این پروژه یک وب‌اپلیکیشن پیشرفته برای مدیریت جلسات است که با استفاده از Gemini API طراحی شده است.

## مراحل دیپلوی روی GitHub Pages

1. **ساخت مخزن در گیت‌هاب:**
   یک مخزن جدید در اکانت گیت‌هاب خود بسازید.

2. **تنظیم API Key:**
   - به بخش **Settings** مخزن بروید.
   - از منوی سمت چپ **Secrets and variables > Actions** را انتخاب کنید.
   - دکمه **New repository secret** را بزنید.
   - نام را `API_KEY` و مقدار را کلید اختصاصی خود از Google AI Studio قرار دهید.

3. **آپلود کد:**
   کدها را به شاخه `main` پوش (Push) کنید. 
   فایل `.github/workflows/deploy.yml` به صورت خودکار عملیات Build و Publish را انجام می‌دهد.

4. **فعال‌سازی Pages:**
   - به بخش **Settings > Pages** بروید.
   - در بخش Build and deployment، منبع (Source) را روی **GitHub Actions** تنظیم کنید.

## استفاده در وردپرس
پس از دیپلوی، لینک تولید شده توسط گیت‌هاب را کپی کرده و در فایل `meetingai-plugin.php` در بخش `src` مربوط به iframe جایگذاری کنید.

توسعه داده شده توسط Soheil Kargar Business Studio