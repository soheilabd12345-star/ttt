
export interface Speaker {
  id: string;
  name: string;
  role: string;
  contribution: string;
}

export interface SubTopic {
  title: string;
  summary: string;
  speakerId?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  role: string;
  plan: string;
}

export interface MeetingSession {
  id: string;
  wpId?: number; 
  title: string;
  description?: string;
  category?: string;
  date: string;
  transcript: string;
  summary: string;
  mainTopic: string;
  subTopics: SubTopic[];
  speakers: Speaker[];
  mainSpeakerId?: string;
  actionItems: ActionItem[];
  assignments: Assignment[];
  scannedImages: string[];
  audioData?: string; // Base64 audio data for persistence
  chatHistory?: { role: 'user' | 'model'; text: string }[];
  groupId?: string; 
}

export interface WordPressConfig {
  siteUrl: string;
  username: string;
  appPassword: string;
  isConnected: boolean;
}

export interface ActionItem {
  id: string;
  task: string;
  status: 'pending' | 'completed';
}

export interface Assignment {
  id: string;
  assignee: string;
  task: string;
  dueDate: string;
}

export interface Group {
  id: string;
  name: string;
  members: string[];
  sessionIds: string[]; 
}

export type AppView = 'home' | 'record' | 'scan' | 'generate' | 'groups' | 'detail' | 'settings' | 'register';
